//
//  Common.h
//  TabAndTable
//
//  Created by Tony on 13-7-29.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Common : NSObject
-(void)drawLineGradient:(CGContextRef) context Rect:(CGRect)rect startColorRef:(CGColorRef)startColor endColor:(CGColorRef)endColor;
@end
