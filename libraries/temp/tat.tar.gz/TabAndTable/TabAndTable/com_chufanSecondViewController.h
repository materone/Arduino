//
//  com_chufanSecondViewController.h
//  TabAndTable
//
//  Created by Tony on 13-7-29.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

@interface com_chufanSecondViewController : UIViewController
{
    NSMutableArray *btnArray;  
    NSMutableArray *titleArray;  

}
@property (nonatomic,strong) IBOutlet UIView *customView;
@property (nonatomic,strong) IBOutlet UIView *backView;
@property (nonatomic,strong) IBOutlet UIButton *myButton;

-(void)myButtonClcik:(id)sender;
@end
