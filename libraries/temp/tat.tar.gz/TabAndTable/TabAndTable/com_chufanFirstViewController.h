//
//  com_chufanFirstViewController.h
//  TabAndTable
//
//  Created by Tony on 13-7-29.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CustomCellBackView.h"

@interface com_chufanFirstViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>{
    UITableView *tableVPanel;
    NSMutableArray *_titleArray;
    NSMutableArray *_itemArray;
}
@property (strong, nonatomic) IBOutlet UITableView *tableVPanel;

@end
