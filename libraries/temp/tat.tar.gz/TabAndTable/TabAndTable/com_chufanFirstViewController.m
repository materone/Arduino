//
//  com_chufanFirstViewController.m
//  TabAndTable
//
//  Created by Tony on 13-7-29.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import "com_chufanFirstViewController.h"

@implementation com_chufanFirstViewController
@synthesize tableVPanel;

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    _titleArray = [[NSMutableArray alloc]initWithObjects:@"Smith",@"Tony",@"Tim", nil];
    _itemArray = [[NSMutableArray alloc]initWithObjects:@"UIKit",@"TableView is a very cool function and the name is a gear smile",@"Object-C", nil];
    tableVPanel.delegate = self;
    tableVPanel.dataSource = self;
   // tableVPanel.layer.borderWidth = 1;
   // tableVPanel.layer.borderColor = [[UIColor redColor]CGColor];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    [self setTableVPanel:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}
#pragma mark - TableView Data
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 2;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if(section == 0){
        return _titleArray.count;
    }else{
        return _itemArray.count;
    }
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    NSString *entry;
    if(indexPath.section == 0){
        entry = [_titleArray objectAtIndex:indexPath.row];
    }else{
        entry = [_itemArray objectAtIndex:indexPath.row];             
    }

    static NSString *identifier = @"cell";
    UITableViewCell *cell = [tableVPanel dequeueReusableCellWithIdentifier:identifier];
    if(cell == nil){
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];  
        
        cell.backgroundView = [[CustomCellBackView alloc]init];
        cell.selectedBackgroundView = [[CustomCellBackView alloc]init];        //general cell
        //cell.textLabel.text = entry;
        //cell.textLabel.backgroundColor=[UIColor clearColor];
        //custome cee
        UILabel *datalab = [[UILabel alloc] initWithFrame:CGRectMake(10, 10, 320, 24)];
        [datalab setTag:100];
        datalab.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
        [cell.contentView addSubview:datalab];
    }
    UILabel *datalab = (UILabel *)[cell.contentView viewWithTag:100];
    [datalab setFont:[UIFont boldSystemFontOfSize:12]];
    datalab.text = entry;
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}

-(NSString*)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    if(section == 0){
        return @"Will Study some...";
    }else{
        return @"Have Study Yeah...";
    }
}

-(NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section{
    if(section == 0){
        return @"Will Study END";
    }else{
        return @"Hava Fun END";
    }
}

@end
